package com.hotelbooking.api.client;

import com.hotelbooking.api.BaseTest;

public class AuthTest extends BaseTest {
    // There could be a test for authorisation, clients options etc.
    // We don't need it right now, assuming that auth, createBooking and getBookingById are working properly.
}
